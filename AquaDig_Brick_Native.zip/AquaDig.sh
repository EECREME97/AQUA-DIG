#!/bin/bash
# AquaDig native ARM64 launcher
HERE="$(cd "$(dirname "$0")" && pwd)"
GAME="$HERE/aquadig"
if [ ! -f "$GAME/aquadig" ]; then
  for d in /mnt/mmc/ports/aquadig /mnt/SDCARD/ports/aquadig /mnt/mmc/Roms/Ports/aquadig /mnt/SDCARD/Roms/Ports/aquadig; do
    if [ -f "$d/aquadig" ]; then GAME="$d"; break; fi
  done
fi
cd "$GAME" || exit 1
exec > "$GAME/log.txt" 2>&1
for d in "${XDG_DATA_HOME:-/nonexistent}/PortMaster" /mnt/mmc/PortMaster /mnt/mmc/ports/PortMaster /mnt/SDCARD/PortMaster /mnt/SDCARD/Emus/shared/PortMaster /mnt/mmc/Emus/shared/PortMaster /mnt/SDCARD/Tools/PortMaster /opt/system/Tools/PortMaster; do
  if [ -f "$d/control.txt" ]; then
    controlfolder="$d"
    . "$d/control.txt"
    if declare -F get_controls >/dev/null; then get_controls; fi
    break
  fi
done
export SDL_GAMECONTROLLERCONFIG
export LD_LIBRARY_PATH="$GAME:$GAME/lib:${LD_LIBRARY_PATH:-}"
cd "$GAME" || exit 1
chmod +x ./aquadig 2>/dev/null || true
./aquadig
