AQUADIG 1.22 - TRIMUI BRICK NATIVE ARM64 - TEST BUILD 1
Original game: Viva La Mobile. This is an experimental native adaptation of the supplied J2ME game, not an official release.

INSTALL
Extract AquaDig.sh and the aquadig folder together into your firmware's Ports directory, usually Roms/Ports or ports. Do not copy just the executable. Launch AquaDig from your Ports list. Requires an ARM64 glibc Linux firmware with SDL2 (libSDL2-2.0.so.0). No JVM, JAR or emulator needed. Keep this folder writable for saves and log.txt. If launch fails or controls do not respond, send aquadig/log.txt and your firmware name.

CONTROLS (intended physical Brick mapping; pending device verification)
D-pad: steer/drill and navigate menus
A: confirm / fire action
B: back / right soft key / pause in gameplay
X: cargo / left soft key
Y: surface booster (#)
L1: bomb (*)
R1: spare oxygen (0)
START: pause / right soft key
SELECT: cargo / left soft key
START + SELECT: quit (without guaranteed save)
Use original game save/exit menu when available.
Keyboard fallback: arrows; Enter/Z/A confirm; X/B/Esc back; C/Y/Space cargo; V/L bomb; F/R oxygen; G/T booster.
If face buttons are swapped by firmware SDL mapping, add export AQUA_NINTENDO=1 before ./aquadig in the launcher.

DISPLAY
Game layout adapted from 240x320 portrait to 320x240 landscape, scaled with nearest-neighbor filtering to a 640x480 logical display and fullscreen 4:3 device output.

TEST STATUS
Native x86 desktop build exercised through startup, menus, intro, underwater drilling and pause. ARM64 ELF compiled and dependency list inspected, but not executed on actual Brick. File-backed saves and original music rendered to PCM are implemented; full save/resume and audio output have not been verified. Online leaderboard and vibration are not supported. Other late game features have not been exhaustively tested.
